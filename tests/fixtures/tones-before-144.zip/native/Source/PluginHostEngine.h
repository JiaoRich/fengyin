#pragma once
#include "KongDualSlotRouter.h"
#include "SwamToneApplication.h"
#include "MusicTempoPolicy.h"
#include "KongTechniqueProfile.h"

#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_audio_utils/juce_audio_utils.h>
#include <functional>
#include <memory>
#include <atomic>
#include <array>
#include <vector>
#include <optional>
#include <map>
#include <set>

#include "MidiPerformanceSink.h"
#include "RecordingService.h"
#include "AccompanimentAudioService.h"
#include "MasterOutputService.h"
#include "RealtimeMidiQueue.h"
#include "OrderedMidiQueue.h"
#include "MidiOnsetTrace.h"
#include "SwamToneProfile.h"
#include "SwamExpressionCurve.h"
#include "ToneParameterValue.h"
#include "EffectChainState.h"
#include "SwamStringTremolo.h"
#include "AudioStageTiming.h"
#include "ProcessorChangeGate.h"
#include "AudioCallbackTrace.h"

namespace fengyin
{
class RecordingAudioProcessorPlayer final : public juce::AudioProcessorPlayer
{
    friend struct PluginHostEngineTestAccess;
public:
    // Preparing/releasing a third-party processor may take hundreds of ms.
    // Let the callback skip only the changing instrument, not accompaniment.
    void setProcessor(juce::AudioProcessor* processor) {
        processorChangeGate.change([&]{juce::AudioProcessorPlayer::setProcessor(processor);});
    }
    void setRecordingService(RecordingService* service) noexcept { recorder = service; }
    void setAccompanimentService(AccompanimentAudioService* service) noexcept { accompaniment = service; }
    void setMasterOutputService(MasterOutputService* service) noexcept { masterOutput = service; }
    bool enqueueMidi(const juce::MidiMessage& message, double timestampSeconds) noexcept;
    void beginOnsetTrace() noexcept { onsetTrace.begin(); }
    void flushOnsetTrace() { onsetTrace.flush("audio-collector"); }
    void requestPerformanceReset() noexcept { resetRequested.store(true, std::memory_order_release); }
    void setKongResetMode(bool enabled) noexcept { kongResetMode.store(enabled, std::memory_order_release); }
    [[nodiscard]] uint64_t getDroppedMidiEventCount() const noexcept { return midiQueue.droppedCount(); }
    std::atomic<uint64_t> callbackCount { 0 }, callbackOverruns { 0 }, signalBlocks { 0 };
    std::atomic<float> diagnosticSourcePeak { 0 };
    const bool timingEnabled = juce::SystemStats::getEnvironmentVariable("FENGYIN_AUDIO_TIMING", "0") == "1";
    AudioStageTiming stageTiming;
    audioTrace::Accumulator detailedTiming;
    audioTrace::Cadence callbackCadence;
    std::atomic<uint64_t> changeSkippedBlocks{0};
    void audioDeviceIOCallbackWithContext(const float* const* inputs, int numInputs, float* const* outputs,
                                          int numOutputs, int numSamples,
                                          const juce::AudioIODeviceCallbackContext& context) override;
    void audioDeviceAboutToStart(juce::AudioIODevice* device) override;
    void audioDeviceStopped() override;
private:
    ProcessorChangeGate processorChangeGate;
    static constexpr std::size_t midiQueueSize = 8192;
    MidiOnsetTrace onsetTrace;
    void addResetMessages(double timestampSeconds);

    OrderedMidiQueue<midiQueueSize> midiQueue;
    std::atomic<bool> resetRequested { false };
    std::atomic<bool> kongResetMode { false };
    double currentSampleRate = 48000.0;
    RecordingService* recorder = nullptr;
    AccompanimentAudioService* accompaniment = nullptr;
    MasterOutputService* masterOutput = nullptr;
};

class PluginHostEngine final : public MidiPerformanceSink
{
    friend struct PluginHostEngineTestAccess;
public:
    using LoadCallback = std::function<void(bool success, const juce::String& message)>;

    PluginHostEngine();
    ~PluginHostEngine() override;

    void attachTo(juce::AudioDeviceManager& deviceManager);
    void detach();
    [[nodiscard]] bool hasIndependentTechniqueRoute(PerformanceTechnique technique) const noexcept
    {
        if(technique==PerformanceTechnique::tremolo && stringTremolo.available())return true;
        if (kontaktStandardControls.load()) return technique==PerformanceTechnique::vibrato;
        const auto index=static_cast<size_t>(technique);
        if(index>=nativeTechniqueRoutes.size())return false;
        if(kongExpressionMode.load()) {
            if(technique==PerformanceTechnique::vibrato&&kongVibratoCC.load()==1)return true;
            return technique==PerformanceTechnique::flutter && kongDualSlot.active();
        }
        const int route=nativeTechniqueRoutes[index].load();
        if(route==0 || route==((swamExpressionChannel.load()<<8)|(swamExpressionController.load()+1)))return false;
        for(size_t i=0;i<nativeTechniqueRoutes.size();++i)
            if(i!=index && nativeTechniqueRoutes[i].load()==route)return false;
        return true;
    }
    void loadAsync(const juce::PluginDescription& description,
                   double sampleRate,
                   int bufferSize,
                   LoadCallback callback);
    void loadAsync(const juce::PluginDescription& description,
                   double sampleRate,
                   int bufferSize,
                   const juce::MemoryBlock& initialState,
                   LoadCallback callback, bool verifyStateRoundtrip = false);
    void unload();
    void prewarmContainers(const juce::Array<juce::PluginDescription>& descriptions,
                           double sampleRate, int bufferSize);
    [[nodiscard]] size_t idleContainerCount() const noexcept { return containerCache.size(); }
    [[nodiscard]] size_t warmingContainerCount() const noexcept { return containersWarming.size(); }
    void loadEffectAsync(const juce::PluginDescription& description,
                         double sampleRate, int bufferSize, LoadCallback callback);
    void unloadEffect();
    void setRecordingService(RecordingService* service) noexcept { player.setRecordingService(service); }
    juce::String takeStageTimingReport();
    juce::String takeCallbackCadenceReport();
    bool isStageTimingEnabled() const noexcept {return player.timingEnabled;}
    void setAccompanimentService(AccompanimentAudioService* service) noexcept { player.setAccompanimentService(service); }
    void setMasterOutputService(MasterOutputService* service) noexcept { player.setMasterOutputService(service); }
    [[nodiscard]] uint64_t getDroppedMidiEventCount() const noexcept { return player.getDroppedMidiEventCount(); }
    [[nodiscard]] uint64_t getCallbackCount() const noexcept { return player.callbackCount.load(); }
    [[nodiscard]] uint64_t getCallbackOverruns() const noexcept { return player.callbackOverruns.load(); }
    [[nodiscard]] uint64_t getSignalBlocks() const noexcept { return player.signalBlocks.load(); }
    float takeDiagnosticSourcePeak() noexcept { return player.diagnosticSourcePeak.exchange(0); }

    [[nodiscard]] bool hasPlugin() const noexcept;
    [[nodiscard]] juce::String getPluginName() const;
    [[nodiscard]] juce::String getPluginIdentifier() const;
    [[nodiscard]] juce::AudioPluginInstance* getPlugin() const noexcept;
    [[nodiscard]] bool hasEffect() const noexcept { return ! effectNodes.empty(); }
    [[nodiscard]] EffectChainStates captureEffectChain();
    [[nodiscard]] juce::var describeEffectChain() const;
    void restoreEffectChain(const EffectChainStates&, double, int, LoadCallback);
    bool removeEffectAt(int index);
    bool moveEffect(int index, int destination);
    bool setEffectBypassedAt(int index, bool bypassed);
    bool showEffectEditor(int index);
    [[nodiscard]] juce::MemoryBlock captureInstrumentState();
    [[nodiscard]] juce::String getInstrumentDescriptionXml() const;
    [[nodiscard]] juce::String getEffectName() const;
    [[nodiscard]] juce::String getEffectIdentifier() const;
    [[nodiscard]] juce::MemoryBlock saveEffectState() const;
    bool restoreEffectState(const void* data, std::size_t size);
    bool setEffectBypassed(bool shouldBypass);
    [[nodiscard]] bool isEffectBypassed() const noexcept;
    bool showPluginEditor(bool effect);
    void closePluginEditor(bool effect = false);
    [[nodiscard]] juce::Array<ToneParameterValue> captureToneParameters() const;
    int restoreToneParameters(const juce::Array<ToneParameterValue>& parameters);
    [[nodiscard]] juce::StringArray getProgramNames() const;
    [[nodiscard]] juce::String getCurrentProgramName() const;
    [[nodiscard]] juce::MemoryBlock captureKongState();
    bool restoreKongProject(const juce::MemoryBlock& project);
    [[nodiscard]] juce::MemoryBlock captureContainerState();
    bool restoreContainerState(const juce::MemoryBlock& state);
    bool selectProgramByAliases(const juce::StringArray& aliases);
    [[nodiscard]] juce::StringArray getInstrumentModelNames() const;
    [[nodiscard]] int getCurrentInstrumentModelIndex() const noexcept;
    [[nodiscard]] juce::String getCurrentInstrumentModelName() const;
    bool selectInstrumentModel(int index);
    int applySwamToneProfile(const SwamToneProfile& profile, bool restoreModel = true);
    [[nodiscard]] juce::var getSwamToneAudit() const { return swamToneAudit; }
    bool applyStandardSwamExpressionCurve(bool initialiseNewInstrument = false);
    bool applyExpressionAttackControl();
    bool setBendRange(int semitones);
    int getBendRange() const;
    void configureKongTechniqueProfile(const juce::String& instrumentKey,
                                       const KongTechniqueProfile& profile = {}) noexcept;
    [[nodiscard]] KongTechniqueProfile getKongTechniqueProfile() const { return kongProfile; }
    void flushOnsetTrace() { player.flushOnsetTrace(); destinationTrace.flush("plugin-input"); }

    void channelPressureChanged(int value, double timestampSeconds = 0.0) noexcept override;
    void noteOn(int noteNumber, float velocity, double timestampSeconds = 0.0) noexcept override;
    void noteOff(int noteNumber, double timestampSeconds = 0.0) noexcept override;
    void breathChanged(float value, double timestampSeconds = 0.0) noexcept override;
    void setKongExpressionMode(bool enabled) noexcept
    {
        kongExpressionMode.store(enabled);
        player.setKongResetMode(enabled);
    }
    void pitchBendChanged(float bipolarValue, double timestampSeconds = 0.0) noexcept override;
    void techniqueChanged(PerformanceTechnique technique, float value) noexcept override;
    void automaticVibratoChanged(float input,float fade) noexcept override;
    void setMusicTempoMode(int mode) noexcept { musicTempoMode.store(MusicTempoPolicy::valid(mode));tempoRateDirty.store(true);stringTremolo.setTempoMode(mode); }
    void resetPerformance() noexcept override;
    void flushTechniqueValues();
    [[nodiscard]] bool supportsTechnique(PerformanceTechnique technique) const noexcept;
    [[nodiscard]] int getProcessingLatencySamples() const noexcept;

private:
    void routeTechnique(PerformanceTechnique technique,float value) noexcept;
    void prepareTempoVibrato(juce::AudioPluginInstance& plugin);
    std::atomic<int> musicTempoMode {1};
    std::atomic<bool> automaticVibratoActive {false},tempoRateDirty {false};
    std::atomic<juce::AudioProcessorParameter*> vibratoRateParameter {nullptr};
    float originalVibratoRate=0;std::array<float,3> tempoVibratoRates {{-1,-1,-1}};
    juce::var swamToneAudit;
    bool queue(juce::MidiMessage message, double timestampSeconds) noexcept;
    bool queueKongPerformance(const juce::MidiMessage& message, double timestampSeconds) noexcept;
    bool rebuildConnections();
    void resolveTechniqueParameters();
    void resolveInstrumentModelParameter();

    juce::AudioPluginFormatManager formatManager;
    RecordingAudioProcessorPlayer player;
    MidiOnsetTrace destinationTrace;
    SwamStringTremolo stringTremolo;
    std::unique_ptr<juce::AudioProcessorGraph> graph;
    juce::AudioProcessorGraph::Node::Ptr instrumentNode;
    struct EffectSlot
    {
        juce::AudioProcessorGraph::Node::Ptr node;
        juce::PluginDescription description;
    };
    std::vector<EffectSlot> effectNodes;
    struct CachedContainer
    {
        std::unique_ptr<juce::AudioPluginInstance> instance;
        std::unique_ptr<juce::AudioProcessorGraph> graph;
        juce::AudioProcessorGraph::Node::Ptr instrument, output, midi;
    };
    // At most one idle Qin and one idle Kontakt engine; never all tone samples.
    std::map<juce::String, std::shared_ptr<CachedContainer>> containerCache;
    std::set<juce::String> containersWarming;
    using WarmCompletion = std::function<void(std::unique_ptr<juce::AudioPluginInstance>, const juce::String&)>;
    std::map<juce::String, WarmCompletion> containerWarmWaiters;
    void parkCurrentContainer();
    juce::AudioProcessorGraph::Node::Ptr audioOutputNode;
    juce::AudioProcessorGraph::Node::Ptr midiInputNode;
    juce::PluginDescription currentDescription;
    juce::Array<ToneParameterValue> releaseBaseline;
    juce::Array<ToneParameterValue> previousReleaseParameters;
    class PluginEditorWindow;
    std::unique_ptr<PluginEditorWindow> instrumentEditorWindow;
    std::unique_ptr<PluginEditorWindow> effectEditorWindow;
    juce::AudioDeviceManager* attachedManager = nullptr;
    std::shared_ptr<std::atomic_bool> lifetime = std::make_shared<std::atomic_bool>(true);
    uint64_t loadGeneration = 0;
    uint64_t effectLoadGeneration = 0;
    std::array<std::atomic<juce::AudioProcessorParameter*>, static_cast<size_t>(PerformanceTechnique::count)> techniqueParameters {};
    std::array<std::atomic<float>, static_cast<size_t>(PerformanceTechnique::count)> techniqueValues {};
    std::array<std::atomic<bool>, static_cast<size_t>(PerformanceTechnique::count)> techniqueDirty {};
    juce::AudioProcessorParameter* instrumentModelParameter = nullptr;
    juce::StringArray instrumentModelNames;
    std::vector<float> instrumentModelValues;
    std::atomic<bool> kongExpressionMode { false };
    std::atomic<int> swamExpressionController { 11 };
    std::atomic<int> swamExpressionChannel { 1 };
    std::array<std::atomic<int>, static_cast<size_t>(PerformanceTechnique::count)> nativeTechniqueRoutes {};
    std::array<std::atomic<int>, static_cast<size_t>(PerformanceTechnique::count)> lastNativeTechniqueMessages {};
    std::atomic<int> lastBreathMidiValue { -1 };
    KongTechniqueProfile kongProfile;
    KongDualSlotRouter kongDualSlot;
    std::atomic<bool> nativePressureEnabled { false }, nativePortamentoInput { false };
    std::atomic<bool> kontaktStandardControls{false};
public:
    void configureKontaktControls(bool enabled) noexcept {
        kontaktStandardControls.store(enabled);
        if(enabled) {queue(juce::MidiMessage::controllerEvent(1,1,0),0.0);tempoRateDirty.store(true);}
    }
private:
    std::atomic<int> kongVibratoCC {-1};
    std::array<std::atomic<float>, static_cast<size_t>(PerformanceTechnique::count)> kongTechniqueInputs {};
    std::array<std::atomic<bool>, 128> activeNotes {};
    juce::SpinLock performanceEventLock;
    std::array<std::atomic<float>, 128> activeVelocities {};
    std::atomic<int> performanceChannel { 1 };
    std::atomic<int> lastPitchWheel { 8192 };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PluginHostEngine)
};
}
